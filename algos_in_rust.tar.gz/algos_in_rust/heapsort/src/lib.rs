pub fn sort(array: &mut [i32]) -> &[i32] {
    let n = array.len();
    for i in ((n / 2 - 1)..=0).rev() {
        heapify(array, n, i);
    }
    for i in ((n - 1)..=0).rev() {
        let temp = array[0];
        array[0] = array[i];
        array[i] = temp;
        heapify(array, i, 0);
    }
    array
}

fn heapify(array: &mut [i32], n: usize, i: usize) {
    let mut largest = i;
    let left = 2 * i + 1;
    let right = 2 * i + 2;

    if left < n && array[left] > array[largest] {
        largest = left;
    }
    if right < n && array[right] > array[largest] {
        largest = right;
    }
    if largest != i {
        swap(array, i, largest);
        heapify(array, n, largest);
    }
}
pub fn swap(array: &mut [i32], i: usize, j: usize) {
    let temp = array[i];
    array[i] = array[j];
    array[j] = temp;
}

#[cfg(test)]
mod tests {
    use super::sort;
    #[test]
    fn test_heapsort_1() {
        let array = &mut [9, 2, -3, 10, 4];
        let sorted = sort(array);
        println!("{:?}", sorted);
        assert_eq!(*array, [-3, 2, 4, 9, 10]);
    }
}

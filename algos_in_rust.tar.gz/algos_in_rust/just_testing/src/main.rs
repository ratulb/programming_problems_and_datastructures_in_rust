use std::env;
fn main() {
    let e = env::var("test");
    type_of(&e);
    let r = match e {
        Ok(sv) =>  sv,
        Err(_) => String::new(),
    };

    //let s = "ratul pupu hoonmoni bhaiti";
    let v = r.split_whitespace().collect::<Vec<&str>>();
    println!("Here: {:?}", v);
    let s:String = "test".to_owned() + "and";
    let mut v = vec!["1","2","3","4"];
    v.retain(|&entry| entry != "300");
    println!("{:?}", v);
}

/***use std::collections::BinaryHeap;
use std::cmp::Reverse;

pub fn main() {
  if Reverse(200) > Reverse(300) {
    println!("Yes");
  }else {
    println!("No");
  }

  let mut heap = BinaryHeap::new();
  heap.push(Reverse(100));
  heap.push(Reverse(300));
  heap.push(Reverse(200));

  println!("{:?}", heap.pop().unwrap().0);
  println!("{:?}", heap.pop().unwrap().0);
  println!("{:?}", heap.pop().unwrap().0);

}**/

/***trait WithName {
    fn new(name: String) -> Self;

    fn get_name(&self) -> &str;

    fn print(&self) {
    println!("My name is {}", self.get_name())
    }
}
struct Name(String);

impl WithName for Name {
    fn new(name: String) -> Self {
    Name(name)
    }

    fn get_name(&self) -> &str {
    &self.0
    }
}
pub fn main() {
    let zero_sized_vec = Vec::<usize>::with_capacity(0);
    println!("{:?}", zero_sized_vec);
    let mut v = vec![];
    v.push(1);
    v.push(2);
    v.push(3);
    println!("{:?}", v);

    let r2: Result<bool, String> = Ok(true);
    let r1: Result<bool, String> = Err("xyz".to_string());
    if r1.and(r2).is_ok() {
       println!("Yes");
    }else {
       println!("No");
    }
}***/


/***#[derive(Debug, Clone)]
struct Node<T> {
  pub value: T,
  pub next: Option<Box<Node<T>>>,
}

impl <T> Node<T> {
  fn new(t: T) -> Self {
    Node {
      value: t,
      next: None,
    }
  }

}

fn main() {
  let n1 = Node::new(1);
  //println!("n1: {:?}", n1);
  let mut n2 = Node::new(2);
  n2.next = Some(Box::new(n1));
  //println!("n2: {:?}", n2);
  let mut some_n2 = Some(n2);
  some_n2.map(|x| {
    type_of(&x);
    100
  }   
  );
  /***some_n2.map(|node| {
      type_of(&node);
      some_n2 = node.next.map(|b| *b);
      node.value
      
  });***/
  
  //println!("mapped: {:?}", mapped);


}***/

/***pub fn main() {
 /***let some = Some(&100);
 type_of(&some);
 let some_as_ref = some.as_ref();
 type_of(&some_as_ref);
 println!("print {:p}", &some_as_ref);
 let some_as_deref = some.as_deref();
 type_of(&some_as_deref);***/
 let some_boxed = Some(Box::new(100));
 type_of(&some_boxed);
 type_of(&some_boxed.as_deref());
}***/
use std::fmt::Debug;
fn type_of<T: Debug>(t: &T) {
  println!("The type is {} and value is {:?}", std::any::type_name::<T>(), *t);
}
/***struct Coords {
  pub x: i64,
  pub y: i64,
}
fn shift_x_twice(coords: &mut Coords, delta: &i64) {
  coords.x += *delta;
  coords.x += *delta;
}

fn main() {
  let mut a = Coords{x: 10, y: 10};
  let delta_a = 10;
  shift_x_twice(&mut a, &delta_a);  // All good.

  let mut b = Coords{x: 10, y: 10};
  let delta_b = &mut b.x;
  println!("delta_b1: {}", delta_b);
  *delta_b += *delta_b;
  println!("delta_b2: {}", delta_b);
  //shift_x_twice(&mut b, delta_b);  // Compilation failure. 
  *delta_b += *delta_b;
  println!("delta_b3: {}", delta_b);

  println!("From here");
  let values: [u32; 5] = [1, 2, 3, 4, 5];
  //let slice: &[u32] = &values;
  println!("The slice: {:?}", values);
  println!("The slice: {:?}", values);
  let mut v = values[2];
  println!("The v: {}", v);
  v = 100;
  println!("The v: {}", v);
  println!("The slice: {:?}", values);

}***/

/*use std::cmp::Reverse;
use std::collections::BinaryHeap;
pub fn main() {
    let mut heap = BinaryHeap::new();
    let mut point1 = PointWithDistance { x: 1, y: 1, d: 0.0 };
    let mut point2 = PointWithDistance { x: 2, y: 2, d: 0.0 };
    let mut point3 = PointWithDistance { x: 3, y: 3, d: 0.0 };
    let mut point4 = PointWithDistance { x: 4, y: 4, d: 0.0 };

    point1.distance();
    point2.distance();
    point3.distance();
    point4.distance();

    heap.push(Reverse(point1));
    heap.push(Reverse(point3));
    heap.push(Reverse(point4));
    heap.push(Reverse(point2));

    println!("{:?}", heap.pop());
    println!("{:?}", heap.pop());
    println!("{:?}", heap.pop());
    println!("{:?}", heap.pop());
    println!("{:?}", heap.pop());

    println!("{:?}", heap);
}
#[derive(Debug, Copy, Clone)]
struct PointWithDistance {
    x: i32,
    y: i32,
    d: f32,
}

use std::cmp::Ord;
use std::cmp::Ordering;

impl Ord for PointWithDistance {
    fn cmp(&self, other: &Self) -> Ordering {
        //self.d.cmp(&other.d)
        if self.d > other.d {
          Ordering::Greater
        }else if self.d < other.d {
          Ordering::Less
        }else {
          Ordering::Equal
        }
        
    }
}

impl PartialOrd for PointWithDistance {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}
impl PartialEq for PointWithDistance {
    fn eq(&self, other: &Self) -> bool {
        self.d == other.d
    }
}

impl Eq for PointWithDistance {}

impl PointWithDistance {
    pub fn distance(&mut self) -> f32 {
        let d_sqd = self.x.pow(2) + self.y.pow(2);
        self.d = ((f32::sqrt(d_sqd as f32)) * 1000.0).round()/1000.0;
        self.d
    }
}*/

mod permutations;
use permutations::*;
fn main() {
    permutate(String::from("abc"));
}

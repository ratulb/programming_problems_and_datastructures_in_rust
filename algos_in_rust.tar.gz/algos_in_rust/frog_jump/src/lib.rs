use std::collections::HashMap;
use std::collections::HashSet;

pub fn can_cross(stones: Vec<i32>) -> bool {
    if stones[1] > 1 {
        return false;
    }
    let mut jumped_from = HashMap::<usize, HashSet<usize>>::new();
    for i in 2..stones.len() {
        jumped_from.insert(stones[i] as usize, HashSet::new());
    }
    for i in 1..stones.len() - 1 {
        let v = stones[i];
        for j in vec![v - 1, v, v + 1] {
            let k = j as usize;
            if jumped_from.contains_key(&k) {
                println!("Yes");
            }
        }
    }

    true
}

#[cfg(test)]
mod tests {
    #[test]
    fn it_works() {
        assert_eq!(2 + 2, 4);
    }
}

use std::cmp;
use std::convert::TryInto;

pub fn max_area(heights: &Vec<i32>) -> i32 {
    let left_bounds = left_bounds(heights);
    let right_bounds = right_bounds(heights);
    let mut max_area = (right_bounds[0] - left_bounds[0] - 1) * heights[0];
    for (index, height) in heights[1..].iter().enumerate() {
        println!("The index and height: {},{}", index, height);
        max_area = cmp::max(
            max_area,
            (right_bounds[index] - left_bounds[index] - 1) * height,
        );
    }
    max_area
}

fn left_bounds(heights: &Vec<i32>) -> Vec<i32> {
    let mut bounds: Vec<i32> = vec![0; heights.len()];
    bounds[0] = -1;
    for index in (1..heights.len()).rev() {
        let mut extent: i32 = index as i32;
        while extent > 0 && heights[index] <= heights[(extent -1) as usize] {
            extent -= 1;
        }
        bounds[index] = extent.try_into().unwrap();
    }
    bounds
}

fn right_bounds(heights: &Vec<i32>) -> Vec<i32> {
    let mut bounds: Vec<i32> = vec![0; heights.len()];
    bounds[heights.len() - 1] = heights.len() as i32;
    for index in 0..heights.len() - 1 {
        let mut extent: i32 = index as i32;
        while extent <= (heights.len() - 2) as i32 && heights[index] <= heights[(extent+1) as usize] {
            extent += 1;
        }
        bounds[index] = extent.try_into().unwrap();
    }
    bounds
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn left_bounds_test() {
        let heights = vec![8, 9];
        assert_eq!(left_bounds(&heights), vec![-1, 0]);
        println!("Left bounds: {:?}", left_bounds(&heights));
        let heights = vec![9, 9];
        assert_eq!(left_bounds(&heights), vec![-1, -1]);
        println!("Left bounds: {:?}", left_bounds(&heights));
    }
    #[test]
    fn right_bounds_test() {
        let heights = vec![8, 9];
        println!("Rights bounds: {:?}", right_bounds(&heights));
        println!("Lefty bounds: {:?}", left_bounds(&heights));
        assert_eq!(right_bounds(&heights), vec![2, 2]);
        let heights = vec![8, 8, 8];
        println!("Rights bounds: {:?}", right_bounds(&heights));
        assert_eq!(right_bounds(&heights), vec![3, 3, 3]);
    }
    #[test]
    fn max_area_test() {
        let heights = vec![8, 9];
        println!("Input: {:?}", heights);
        println!("Left Left bounds: {:?}", left_bounds(&heights));
        println!("Right bound: {:?}", right_bounds(&heights));
        println!("Max area: {:?}", max_area(&heights));
        assert_eq!(max_area(&heights), 16);
        let heights = vec![8, 8, 8];
        println!("Max area: {:?}", max_area(&heights));
        assert_eq!(max_area(&heights), 24);
    }
}

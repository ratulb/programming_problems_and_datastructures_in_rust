///Search in an infinite sorted array

#[cfg(test)]
mod tests {
    #[test]
    fn it_works() {
        let array = [0 as u32; 100000];
        println!("1000th elem: {:?}", array[1001]);
        assert_eq!(2 + 2, 4);
    }
}
